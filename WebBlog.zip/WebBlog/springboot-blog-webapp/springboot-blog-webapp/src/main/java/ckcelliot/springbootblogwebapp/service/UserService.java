package ckcelliot.springbootblogwebapp.service;

import ckcelliot.springbootblogwebapp.dto.RegistrationDto;
import ckcelliot.springbootblogwebapp.entity.User;

public interface UserService {
    void saveUser(RegistrationDto registrationDto);

    User findByEmail(String email);
}
