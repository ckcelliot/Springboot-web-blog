package ckcelliot.springbootblogwebapp.util;

public enum ROLE {
    ROLE_ADMIN,
    ROLE_GUEST
}
