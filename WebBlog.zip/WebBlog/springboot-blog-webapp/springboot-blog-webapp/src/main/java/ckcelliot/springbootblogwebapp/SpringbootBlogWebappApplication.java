package ckcelliot.springbootblogwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootBlogWebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootBlogWebappApplication.class, args);
	}

}
