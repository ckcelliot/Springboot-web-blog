-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: webblogapp
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` tinytext,
  `created_on` datetime(6) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `updated_on` datetime(6) DEFAULT NULL,
  `post_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKh4c7lvsc298whoyd4w9ta25cr` (`post_id`),
  CONSTRAINT `FKh4c7lvsc298whoyd4w9ta25cr` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,'Great!','2024-01-22 22:18:37.410435','admin@gmail.com','admin','2024-01-22 22:18:37.410435',1);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `created_on` datetime(6) DEFAULT NULL,
  `short_description` varchar(500) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `updated_on` datetime(6) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `created_by` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4s8wtgwpo1h8p5tsy9f04ybjg` (`created_by`),
  CONSTRAINT `FK4s8wtgwpo1h8p5tsy9f04ybjg` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,'<p>OOPs (Object-Oriented Programming System)</p><p><strong>Object</strong> means a real-world entity such as a pen, chair, table, computer, watch, etc. <strong>Object-Oriented Programming</strong> is a methodology or paradigm to design a program using classes and objects. It simplifies software development and maintenance by providing some concepts:</p><h2>&nbsp;</h2><h2>【Object】</h2><p>Any entity that has state and behavior is known as an object. For example, a chair, pen, table, keyboard, bike, etc. It can be physical or logical.</p><p>An Object can be defined as an instance of a class. An object contains an address and takes up some space in memory. Objects can communicate without knowing the details of each other\'s data or code. The only necessary thing is the type of message accepted and the type of response returned by the objects.</p><p><strong>Example:</strong> A dog is an object because it has states like color, name, breed, etc. as well as behaviors like wagging the tail, barking, eating, etc.</p><p>&nbsp;</p><h2>【Class】</h2><p><i>Collection of objects</i> is called class. It is a logical entity.</p><p>A class can also be defined as a blueprint from which you can create an individual object. Class doesn\'t consume any space.</p><p>&nbsp;</p><h3>【Inheritance】</h3><p><i>When one object acquires all the properties and behaviors of a parent object</i>, it is known as inheritance. It provides code reusability. It is used to achieve runtime polymorphism.</p><p>&nbsp;</p><h3>【Polymorphism】</h3><p>If <i>one task is performed in different ways</i>, it is known as polymorphism. For example: to convince the customer differently, to draw something, for example, shape, triangle, rectangle, etc.</p><p>In Java, we use method overloading and method overriding to achieve polymorphism.</p><p>Another example can be to speak something; for example, a cat speaks meow, dog barks woof, etc.</p><h4>&nbsp;</h4><h4>【Abstraction】</h4><p><i>Hiding internal details and showing functionality</i> is known as abstraction. For example phone call, we don\'t know the internal processing.</p><p>In Java, we use abstract class and interface to achieve abstraction.</p><h3>&nbsp;</h3><h3>【Encapsulation】</h3><p><i>Binding (or wrapping) code and data together into a single unit are known as encapsulation</i>. For example, a capsule, it is wrapped with different medicines.</p><p>A java class is the example of encapsulation. Java bean is the fully encapsulated class because all the data members are private here.</p><p>&nbsp;</p>','2023-12-16 10:45:00.000000','In this page, we will learn about the basics of OOPs. Object-Oriented Programming is a paradigm that provides many concepts, such as inheritance, data binding, polymorphism, etc.','Java OOPs Concepts','2024-01-22 22:27:23.173283','oops-concepts-in-java',1),(2,'<p>There are four types of JDBC drivers:</p><ul><li>DBC-ODBC Bridge Driver,</li><li>Native Driver,</li><li>Network Protocol Driver, and</li><li>Thin Driver</li></ul><p>&nbsp;</p><p>We can use JDBC API to access tabular data stored in any relational database. By the help of JDBC API, we can save, update, delete and fetch data from the database. It is like Open Database Connectivity (ODBC) provided by Microsoft.</p><p><img src=\"https://static.javatpoint.com/images/core/jdbc.png\" alt=\"JDBC (Java Database Connectivity) \" width=\"473\" height=\"203\"></p><p>&nbsp;</p><h3>Why Should We Use JDBC</h3><p>Before JDBC, ODBC API was the database API to connect and execute the query with the database. But, ODBC API uses ODBC driver which is written in C language (i.e. platform dependent and unsecured). That is why Java has defined its own API (JDBC API) that uses JDBC drivers (written in Java language).</p><p>We can use JDBC API to handle database using Java program and can perform the following activities:</p><ol><li>Connect to the database</li><li>Execute queries and update statements to the database</li><li>Retrieve the result received from the database.</li></ol>','2023-12-16 10:45:00.000000','JDBC stands for Java Database Connectivity. JDBC is a Java API to connect and execute the query with the database. It is a part of JavaSE (Java Standard Edition). JDBC API uses JDBC drivers to connect with the database. ','Java JDBC Tutorial','2024-01-22 22:36:52.145046','variables-in-java',1),(3,'<h2><strong>Primitive Data Types</strong></h2><p>The Java programming language is statically-typed, which means that all variables must first be declared before they can be used. This involves stating the variable\'s type and name, as you\'ve already seen:</p><p>int gear = 1;</p><p>Doing so tells your program that a field named \"gear\" exists, holds numerical data, and has an initial value of \"1\". A variable\'s data type determines the values it may contain, plus the operations that may be performed on it. In addition to int, the Java programming language supports seven other <i>primitive data types</i>. A primitive type is predefined by the language and is named by a reserved keyword. Primitive values do not share state with other primitive values. The eight primitive data types supported by the Java programming language are:</p><p><strong>byte</strong>: The byte data type is an 8-bit signed two\'s complement integer. It has a minimum value of -128 and a maximum value of 127 (inclusive). The byte data type can be useful for saving memory in large <a href=\"https://docs.oracle.com/javase/tutorial/java/nutsandbolts/arrays.html\">arrays</a>, where the memory savings actually matters. They can also be used in place of int where their limits help to clarify your code; the fact that a variable\'s range is limited can serve as a form of documentation.</p><p><strong>short</strong>: The short data type is a 16-bit signed two\'s complement integer. It has a minimum value of -32,768 and a maximum value of 32,767 (inclusive). As with byte, the same guidelines apply: you can use a short to save memory in large arrays, in situations where the memory savings actually matters.</p><p><strong>int</strong>: By default, the int data type is a 32-bit signed two\'s complement integer, which has a minimum value of -231 and a maximum value of 231-1. In Java SE 8 and later, you can use the int data type to represent an unsigned 32-bit integer, which has a minimum value of 0 and a maximum value of 232-1. Use the Integer class to use int data type as an unsigned integer. See the section The Number Classes for more information. Static methods like compareUnsigned, divideUnsigned etc have been added to the <a href=\"https://docs.oracle.com/javase/8/docs/api/java/lang/Integer.html\">Integer</a> class to support the arithmetic operations for unsigned integers.</p><p><strong>long</strong>: The long data type is a 64-bit two\'s complement integer. The signed long has a minimum value of -263 and a maximum value of 263-1. In Java SE 8 and later, you can use the long data type to represent an unsigned 64-bit long, which has a minimum value of 0 and a maximum value of 264-1. Use this data type when you need a range of values wider than those provided by int. The <a href=\"https://docs.oracle.com/javase/8/docs/api/java/lang/Long.html\">Long</a> class also contains methods like compareUnsigned, divideUnsigned etc to support arithmetic operations for unsigned long.</p><p><strong>float</strong>: The float data type is a single-precision 32-bit IEEE 754 floating point. Its range of values is beyond the scope of this discussion, but is specified in the <a href=\"https://docs.oracle.com/javase/specs/jls/se7/html/jls-4.html#jls-4.2.3\">Floating-Point Types, Formats, and Values</a> section of the Java Language Specification. As with the recommendations for byte and short, use a float (instead of double) if you need to save memory in large arrays of floating point numbers. This data type should never be used for precise values, such as currency. For that, you will need to use the <a href=\"https://docs.oracle.com/javase/8/docs/api/java/math/BigDecimal.html\">java.math.BigDecimal</a> class instead. <a href=\"https://docs.oracle.com/javase/tutorial/java/data/index.html\">Numbers and Strings</a> covers BigDecimal and other useful classes provided by the Java platform.</p><p><strong>double</strong>: The double data type is a double-precision 64-bit IEEE 754 floating point. Its range of values is beyond the scope of this discussion, but is specified in the <a href=\"https://docs.oracle.com/javase/specs/jls/se7/html/jls-4.html#jls-4.2.3\">Floating-Point Types, Formats, and Values</a> section of the Java Language Specification. For decimal values, this data type is generally the default choice. As mentioned above, this data type should never be used for precise values, such as currency.</p><p><strong>boolean</strong>: The boolean data type has only two possible values: true and false. Use this data type for simple flags that track true/false conditions. This data type represents one bit of information, but its \"size\" isn\'t something that\'s precisely defined.</p><p><strong>char</strong>: The char data type is a single 16-bit Unicode character. It has a minimum value of \'\\u0000\' (or 0) and a maximum value of \'\\uffff\' (or 65,535 inclusive).</p>','2023-12-16 10:45:00.000000','Primitive Data Types. The eight primitives defined in Java are int, byte, short, long, float, double, boolean and char. These aren\'t considered objects and represent raw values.','Introduction to Java Primitives','2024-01-22 22:42:48.311911','primitive-data-types-in-java',1),(4,'<p>In Java, access modifiers are used to set the accessibility (visibility) of classes, interfaces, variables, methods, constructors, data members, and the setter methods. For example,</p><p>class Animal {\r\n &nbsp; &nbsp;</p><p>public void method1() {...}\r\n\r\n &nbsp;&nbsp;</p><p>private void method2() {...}\r\n}</p><p>&nbsp;</p><p>In the above example, we have declared 2 methods: method1() and method2(). Here,</p><ul><li>method1 is public - This means it can be accessed by other classes.</li><li>method2 is private - This means it can not be accessed by other classes.</li></ul><p>Note the keyword public and private. These are access modifiers in Java. They are also known as visibility modifiers.</p><p><strong>Note</strong>: You cannot set the access modifier of getters methods.</p><h2>&nbsp;</h2><h2>Types of Access Modifier</h2><p>Before you learn about types of access modifiers, make sure you know about <a href=\"https://www.programiz.com/java-programming/packages-import\">Java Packages</a>.</p><p>There are four access modifiers keywords in Java and they are:</p><figure class=\"table\"><table><tbody><tr><td><strong>Modifier</strong></td><td><strong>Description</strong></td></tr><tr><td>Default</td><td>declarations are visible only within the package (package private)</td></tr><tr><td>Private</td><td>declarations are visible within the class only</td></tr><tr><td>Protected</td><td>declarations are visible within the package or all subclasses</td></tr><tr><td>Public</td><td>declarations are visible everywhere</td></tr></tbody></table></figure>','2023-12-16 10:45:00.000000','What are Access Modifiers? Access modifiers are keywords that can be used to control the visibility of fields, methods, and constructors in a class. The four access modifiers in Java are public, protected, default, and private.','Java Access Modifiers','2024-01-22 22:46:01.087391','access-modifiers-in-java',1),(7,'<p>If we have to perform only one operation, having same name of the methods increases the readability of the <a href=\"https://www.javatpoint.com/java-programs\">program</a>.</p><p>Suppose you have to perform addition of the given numbers but there can be any number of arguments, if you write the method such as a(int,int) for two parameters, and b(int,int,int) for three parameters then it may be difficult for you as well as other programmers to understand the behavior of the method because its name differs.</p><p>So, we perform method overloading to figure out the program quickly.</p>','2024-01-22 22:56:04.950423','If a class has multiple methods having same name but different in parameters, it is known as Method Overloading.\r\n','Method Overloading in Java','2024-01-22 22:56:04.951420','method-overloading-in-java',2),(8,'<figure class=\"table\"><table><thead><tr><th>Class</th><th>Object</th></tr></thead><tbody><tr><td>A class is a blueprint for declaring and creating objects.</td><td>An object is a class instance that allows programmers to use variables and methods from inside the class.</td></tr><tr><td>Memory is not allocated to classes. Classes have no physical existence.</td><td>When objects are created, memory is allocated to them in the heap memory.</td></tr><tr><td>You can declare a class only once.</td><td>A class can be used to create many objects.</td></tr><tr><td>Class is a logical entity.</td><td>An object is a physical entity.</td></tr><tr><td>We cannot manipulate class as it is not available in memory.</td><td>Objects can be manipulated.</td></tr><tr><td>Class is created using the class keyword like class Dog{}</td><td>Objects are created through new keyword like Dog d = new Dog();. We can also create an object using the newInstance() method, clone() method, fatory method and using deserialization.</td></tr><tr><td>Example: Mobile is a class.</td><td>If Mobile is the class then iphone, redmi, blackberry, samsung are its objects which have different properties and behaviours.</td></tr><tr><td>Classes can have attributes and methods defined.</td><td>Objects can have specific values assigned to their attributes.</td></tr><tr><td>Classes serve as blueprints for creating objects.</td><td>Objects represent specific instances created from a class.</td></tr></tbody></table></figure>','2024-01-23 13:12:39.040370','A class is a group of similar objects. Object is a real-world entity such as book, car, etc. Class is a logical entity. Object is a physical entity.','Difference between object and class','2024-01-23 13:12:39.040370','difference-between-object-and-class',1),(9,'<p>Method overloading refers to defining multiple methods with the same name but different parameters within the same class, while method overriding involves creating a method in the child class that has the same name, parameters, and return type as a method in the parent class.</p><p>There are many differences between method overloading and method overriding in java. A list of differences between method overloading and method overriding are given below:</p><figure class=\"table\"><table><thead><tr><th>No.</th><th>Method Overloading</th><th>Method Overriding</th></tr></thead><tbody><tr><td>1)</td><td>Method overloading is used <i>to increase the readability</i> of the program.</td><td>Method overriding is used <i>to provide the specific implementation</i> of the method that is already provided by its super class.</td></tr><tr><td>2)</td><td>Method overloading is performed <i>within class</i>.</td><td>Method overriding occurs <i>in two classes</i> that have IS-A (inheritance) relationship.</td></tr><tr><td>3)</td><td>In case of method overloading, <i>parameter must be different</i>.</td><td>In case of method overriding, <i>parameter must be same</i>.</td></tr><tr><td>4)</td><td>Method overloading is the example of <i>compile time polymorphism</i>.</td><td>Method overriding is the example of <i>run time polymorphism</i>.</td></tr><tr><td>5)</td><td>In java, method overloading can\'t be performed by changing return type of the method only. <i>Return type can be same or different</i> in method overloading. But you must have to change the parameter.</td><td><i>Return type must be same or covariant</i> in method overriding.</td></tr></tbody></table></figure><p>&nbsp;</p><h2>Java Method Overloading example</h2><p>&nbsp;</p><ol><li><strong>class</strong>&nbsp;OverloadingExample{&nbsp;&nbsp;</li><li><strong>static</strong>&nbsp;<strong>int</strong>&nbsp;add(<strong>int</strong>&nbsp;a,<strong>int</strong>&nbsp;b){<strong>return</strong>&nbsp;a+b;}&nbsp;&nbsp;</li><li><strong>static</strong>&nbsp;<strong>int</strong>&nbsp;add(<strong>int</strong>&nbsp;a,<strong>int</strong>&nbsp;b,<strong>int</strong>&nbsp;c){<strong>return</strong>&nbsp;a+b+c;}&nbsp;&nbsp;</li><li>}&nbsp;&nbsp;</li></ol><h2>Java Method Overriding example</h2><p>&nbsp;</p><ol><li><strong>class</strong>&nbsp;Animal{&nbsp;&nbsp;</li><li><strong>void</strong>&nbsp;eat(){System.out.println(\"eating...\");}&nbsp;&nbsp;</li><li>}&nbsp;&nbsp;</li><li><strong>class</strong>&nbsp;Dog&nbsp;<strong>extends</strong>&nbsp;Animal{&nbsp;&nbsp;</li><li><strong>void</strong>&nbsp;eat(){System.out.println(\"eating&nbsp;bread...\");}&nbsp;&nbsp;</li><li>}&nbsp;&nbsp;</li></ol>','2024-01-23 13:18:00.000000','Method overriding is a run-time polymorphism. Method overloading helps to increase the readability of the program. ','Difference between method overloading and method overriding in java','2024-01-23 13:20:41.194048','difference-between-method-overloading-and-method-overriding-in-java',1);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ROLE_ADMIN'),(2,'ROLE_GUEST');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_6dotkott2kjsp8vw4d0m25fb7` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@gmail.com','admin admin','$2a$10$4pYdPD52rHKxpGXz8ZDYL.dSJu6Bq8LiIX2NY2vQ4PrqOznpD48GG'),(2,'etkc@gmail.com','et kc','$2a$10$JZ1lzhwAQwUWz1q60er.5uDCJSgzcgoRp8D2ABc3igg1tqLrc4bKK');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_roles` (
  `user_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  KEY `FKj6m8fwv7oqv74fcehir1a9ffy` (`role_id`),
  KEY `FK2o0jvgh89lemvvo17cbqvdxaa` (`user_id`),
  CONSTRAINT `FK2o0jvgh89lemvvo17cbqvdxaa` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FKj6m8fwv7oqv74fcehir1a9ffy` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_roles`
--

LOCK TABLES `users_roles` WRITE;
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` VALUES (1,2),(2,2);
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-17 13:51:03
